# Project5-HR-Data-Analysis
"Project5-HR Data Analysis: Analyzed HR data to uncover trends in employee performance, retention, and satisfaction. Utilized statistical techniques and visualizations to provide actionable insights for HR decision-making."
